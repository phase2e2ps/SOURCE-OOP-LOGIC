<?php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    session_start();

    require_once "../model/contact-class.php";

    $contact = new Contact();
    $messages = $contact->getMessages();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Messages</title>

    <!-- Bootstrap & Core CSS -->
    <link rel="stylesheet" href="http://192.168.80.168/cwms/admin/css/bootstrap.min.css">
    <link rel="stylesheet" href="http://192.168.80.168/cwms/admin/css/font-awesome.css">
    <link rel="stylesheet" href="http://192.168.80.168/cwms/admin/css/style.css">

    <!-- Custom Global CSS -->
    <link rel="stylesheet" href="http://192.168.80.168/cwms/css/style.css">

    <!-- Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:400,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400">

    <!-- Font Awesome CDN (optional, newer version) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Custom Page Styling -->
    <style>
        body {
            background: #f7f9fc;
            font-family: 'Roboto', sans-serif;
        }
        .grid-form h2 {
            font-weight: 600;
            margin-bottom: 20px;
            color: #333;
            border-left: 5px solid #007bff;
            padding-left: 10px;
        }
        table.table {
            background: #fff;
            border-radius: 6px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        table.table thead {
            background: #007bff;
            color: #fff;
            text-transform: uppercase;
        }
        table.table tbody tr:hover {
            background: #f1f7ff;
        }
        .btn-sm {
            padding: 4px 10px;
            border-radius: 4px;
        }
        .breadcrumb {
            background: none;
            padding: 10px 0;
            font-size: 14px;
        }
        .alert-success {
            border-left: 5px solid #28a745;
            font-weight: 500;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar-menu">
        <header class="logo1">
            <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a>
        </header>
        <div style="border-top:1px ridge rgba(255, 255, 255, 0.15)"></div>
        <div class="menu">
            <ul id="menu">
                <li><a href="./admin-dashboard.php"><i class="fa fa-tachometer"></i> <span>Dashboard</span></a></li>
                <li id="menu-academico"><a href="#"><i class="fa fa-list-ul"></i><span>Washing Points</span><span class="fa fa-angle-right" style="float:right"></span></a>
                    <ul id="menu-academico-sub">
                        <li><a href="addcar-washpoint.php">Add</a></li>
                        <li><a href="managecar-washingpoints.php">Manage</a></li>
                    </ul>
                </li>
                <li><a href="add-booking.php"><i class="fa fa-user"></i> <span>Add Car Wash Booking</span></a></li>
                <li id="menu-academico"><a href="#"><i class="fa fa-files-o"></i><span>Car Washing Booking</span><span class="fa fa-angle-right" style="float:right"></span></a>
                    <ul id="menu-academico-sub">
                        <li><a href="new-booking.php">New</a></li>
                        <li><a href="completed-booking.php">Completed</a></li>
                        <li><a href="all-bookings.php">All</a></li>
                    </ul>
                </li>
                <li><a href="manage-enquires.php"><i class="fa fa-file-text-o"></i> <span>Manage Enquiries</span></a></li>
                <li id="menu-academico"><a href="#"><i class="fa fa-list-ul"></i><span>Pages</span><span class="fa fa-angle-right" style="float:right"></span></a>
                    <ul id="menu-academico-sub">
                        <li><a href="about.php">About</a></li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>

    <!-- Content -->
    <div class="left-content">
        <div class="mother-grid-inner">

            <!-- Header -->
            <div class="header-main">
                <div class="logo-w3-agile">
                    <h1><a href="dashboard.php">Car Wash Management System</a></h1>
                </div>
                <div class="profile_details w3l">
                    <ul>
                        <li class="dropdown profile_details_drop">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <div class="profile_img">
                                    <span class="prfil-img">
                                        <img src="https://thumbs.dreamstime.com/b/car-wash-cartoon-logo-man-using-car-wash-apron-car-wash-cartoon-logo-man-using-car-wash-apron-character-design-vector-124032278.jpg" alt="">
                                    </span>
                                    <div class="user-name">
                                        <p>Welcome</p>
                                        <span>Administrator</span>
                                    </div>
                                    <i class="fa fa-angle-down"></i>
                                    <i class="fa fa-angle-up"></i>
                                </div>
                            </a>
                            <ul class="dropdown-menu drp-mnu">
                                <li><a href="#"><i class="fa fa-lock"></i> Setting</a></li>
                                <li><a href="../views/index.php"><i class="fa fa-sign-out"></i> Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <div class="clearfix"> </div>
            </div>

            <!-- Breadcrumb -->
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="../admin/admin-dashboard.php">Home</a> <i class="fa fa-angle-right"></i> Contact us information</li>
            </ol>

            <!-- Contact Messages -->
            <div class="grid-form">
                <h2>Contact Messages</h2>
                <?php if (isset($_SESSION['msg'])): ?>
                    <div class="alert alert-success">
                        <?= $_SESSION['msg']; unset($_SESSION['msg']); ?>
                    </div>
                <?php endif; ?>

                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Subject</th>
                            <th>Message</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($messages as $msg): ?>
                            <tr>
                                <td><?= htmlspecialchars($msg['id']) ?></td>
                                <td><?= htmlspecialchars($msg['name_tb']) ?></td>
                                <td><?= htmlspecialchars($msg['email_tb']) ?></td>
                                <td><?= htmlspecialchars($msg['subject_tb']) ?></td>
                                <td><?= nl2br(htmlspecialchars($msg['message_tb'])) ?></td>
                                <td>
                                    <?php if ($msg['status_tb'] == 'pending'): ?>
                                        <span class="badge badge-warning">Pending</span>
                                    <?php else: ?>
                                        <span class="badge badge-success">Completed</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="admin-contact-edit.php?id=<?= $msg['id'] ?>" class="btn btn-sm btn-primary">Edit</a>
                                    <a href="admin-contact-delete.php?id=<?= $msg['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                                    <?php if ($msg['status_tb'] == 'pending'): ?>
                                        <a href="admin-contact-complete.php?id=<?= $msg['id'] ?>" class="btn btn-sm btn-success">Mark Complete</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="http://192.168.80.168/cwms/admin/js/jquery-2.1.4.min.js"></script>
    <script src="http://192.168.80.168/cwms/admin/js/bootstrap.min.js"></script>
    <script src="http://192.168.80.168/cwms/admin/js/jquery.nicescroll.js"></script>
    <script src="http://192.168.80.168/cwms/admin/js/scripts.js"></script>
</body>
</html>
