<?php
#----------------------------------#
#----------Delete message----------#
#----------------------------------#

session_start();
require_once "../model/contact-class.php";

$contact = new Contact();
$id = $_GET['id'] ?? null;

if($id) {
    $contact->deleteMessage($id);
    $_SESSION['msg'] = "Message deleted successfully!";
}

header("Location: ./contact.php");
exit;
