<?php
#----------------------------------#
#--------Edit / Update page--------#
#----------------------------------#


session_start();
require_once "../model/contact-class.php";

$contact = new Contact();

$id = $_GET['id'] ?? null;
if(!$id) {
    header("Location: ./contact.php");
    exit;
}

$msg = $contact->getMessages($id);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'name_tb'    => $_POST['name'] ?? '',
        'email_tb'   => $_POST['email'] ?? '',
        'subject_tb' => $_POST['subject'] ?? '',
        'message_tb' => $_POST['message'] ?? ''
    ];

    if($contact->updateMessage($id, $data)) {
        $_SESSION['msg'] = "Message updated successfully!";
        header("Location: ./contact.php");
        exit;
    }else{
        echo "<script class='danger'>alert('Faiied to send message!')</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Contact Message</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2>Edit Message #<?= htmlspecialchars($id) ?></h2>
    <form method="post">
        <div class="form-group">
            <label>Name</label>
            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($msg['name_tb']) ?>">
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($msg['email_tb']) ?>">
        </div>
        <div class="form-group">
            <label>Subject</label>
            <input type="text" name="subject" class="form-control" value="<?= htmlspecialchars($msg['subject_tb']) ?>">
        </div>
        <div class="form-group">
            <label>Message</label>
            <textarea name="message" class="form-control" rows="5" required><?= htmlspecialchars($msg['message_tb']) ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
        <a href="admin-contact.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>
</body>
</html>
