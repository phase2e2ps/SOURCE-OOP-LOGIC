<?php
#----------------------------------#
#---------Mark as complete---------#
#----------------------------------#


session_start();
require_once "../model/contact-class.php";

$contact = new Contact();
$id = $_GET['id'] ?? null;

if($id) {
    $contact->markComplete($id);
    $_SESSION['msg'] = "Message marked as completed!";
}

header("Location: ./contact.php");
exit;
