<?php
require_once "db_connection.php";

class Contact extends Database
{
    private $conn;

    public function __construct()
    {
        // just use parent::connect()
        $this->conn = $this->connect();
    }

    public function sendSMS($data)
    {
        $sql = "INSERT INTO contact_tb (name_tb, email_tb, subject_tb, message_tb) 
                VALUES (:name, :email, :subject, :message)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(":name", $data['name_tb']);
        $stmt->bindParam(":email", $data['email_tb']);
        $stmt->bindParam(":subject", $data['subject_tb']);
        $stmt->bindParam(":message", $data['message_tb']);
        return $stmt->execute();
    }

    public function getMessages()
    {
        $stmt = $this->conn->prepare("SELECT * FROM contact_tb ORDER BY id ASC");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function updateMessage($id, $data)
    {
        $sql = "UPDATE contact_tb SET name_tb = :name, email_tb = :email, subject_tb = :subject, message_tb = :message WHERE id = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(":name", $data['name_tb']);
        $stmt->bindParam(":email", $data['email_tb']);
        $stmt->bindParam(":subject", $data['subject_tb']);
        $stmt->bindParam(":message", $data['message_tb']);
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    public function deleteMessage($id)
    {
        $stmt = $this->conn->prepare("DELETE FROM contact_tb WHERE id = :id");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    public function markComplete($id)
    {
        $stmt = $this->conn->prepare("UPDATE contact_tb SET status_tb='completed' WHERE id = :id");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }
}
