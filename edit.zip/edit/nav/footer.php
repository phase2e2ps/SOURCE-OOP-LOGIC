<!-- Footer Start -->
<div class="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6">
            </div>

        </div>
    </div>
    <div class="container copyright">
        <p>&copy; <?php echo date("Y/M/D"); ?> Carwash Management System</p>
    </div>
</div>
<!-- Footer End -->


</body>

</html>