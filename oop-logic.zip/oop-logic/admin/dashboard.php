<?php include 'header.php'; ?>
<div class="container py-5">
    <h2>Dashboard</h2>
    <div class="row g-4 mt-4">
        <div class="col-md-4">
            <div class="card shadow-sm text-center p-4">
                <h3 id="totalBookings">0</h3>
                <p>Total Bookings</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm text-center p-4">
                <h3 id="pendingBookings">0</h3>
                <p>Pending Bookings</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm text-center p-4">
                <h3 id="completedBookings">0</h3>
                <p>Completed Bookings</p>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/script.js"></script>