document.addEventListener("DOMContentLoaded", () => {
    const bookings = JSON.parse(localStorage.getItem("bookings")) || [];
    
    // Dashboard stats
    const total = bookings.length;
    const pending = bookings.filter(b => b.status === "Pending").length;
    const completed = bookings.filter(b => b.status === "Completed").length;

    if(document.getElementById("totalBookings")) document.getElementById("totalBookings").textContent = total;
    if(document.getElementById("pendingBookings")) document.getElementById("pendingBookings").textContent = pending;
    if(document.getElementById("completedBookings")) document.getElementById("completedBookings").textContent = completed;

    // Populate bookings table
    const table = document.getElementById("bookingTable");
    if(table) {
        table.innerHTML = "";
        bookings.forEach((b, i) => {
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td>${b.name}</td>
                <td>${b.phone}</td>
                <td>${b.car}</td>
                <td>${b.plan}</td>
                <td>${b.date}</td>
                <td>${b.status}</td>
                <td>
                    ${b.status === "Pending" ? `<button class="btn btn-success btn-sm" onclick="markComplete(${i})">Complete</button>` : ""}
                </td>
            `;
            table.appendChild(tr);
        });
    }
});

function markComplete(index) {
    let bookings = JSON.parse(localStorage.getItem("bookings")) || [];
    bookings[index].status = "Completed";
    localStorage.setItem("bookings", JSON.stringify(bookings));
    alert("Booking marked as completed!");
    location.reload();
}
