<?php
require_once "../model/Booking.php";
$booking = new Booking();
$bookings = $booking->getBookings();
?>

<div class="container my-5">
    <h2 class="mb-4">Manage Bookings</h2>

    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Plan</th>
                <th>Name</th>
                <th>Contact</th>
                <th>Car Model</th>
                <th>Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while($row = $bookings->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= $row['plan'] ?></td>
                <td><?= $row['name'] ?></td>
                <td><?= $row['contact'] ?></td>
                <td><?= $row['car_model'] ?></td>
                <td><?= $row['date'] ?></td>
                <td>
                    <?php if($row['status'] == 'Completed'): ?>
                        <span class="badge bg-success">Completed</span>
                    <?php else: ?>
                        <span class="badge bg-warning">Pending</span>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="?edit=<?= $row['id'] ?>" class="btn btn-sm btn-primary">Edit</a>
                    <a href="process_booking.php?delete=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this booking?')">Delete</a>
                    <?php if($row['status'] != 'Completed'): ?>
                    <a href="process_booking.php?complete=<?= $row['id'] ?>" class="btn btn-sm btn-success">Mark Complete</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
