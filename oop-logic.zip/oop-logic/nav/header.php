    <!-- Header -->
    <header class="p-3 mb-3">
        <div class="container d-flex flex-wrap align-items-center justify-content-between">
            <a href="#" class="fs-4 fw-bold text-white text-decoration-none">🚗 CarWash Management</a>
            <ul class="nav">
                <li><a href="../views/index.php" class="nav-link px-2">Dashboard</a></li>
                <li><a href="../views/services.php" class="nav-link px-2">Services</a></li>
                <li><a href="../views/pricing.php" class="nav-link px-2">Pricing</a></li>
                <li><a href="../views/features.php" class="nav-link px-2">Why Us</a></li>
                <li><a href="../views/testimonials.php" class="nav-link px-2">Testimonials</a></li>
                <li><a href="../views/contact.php" class="nav-link px-2">Contact</a></li>
                <li><a href="../admin/dashboard.php" class="nav-link px-2">Admin</a></li>
            </ul>
        </div>
    </header>