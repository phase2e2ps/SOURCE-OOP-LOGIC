    <footer class="bg-primary text-white text-center py-4">
        <div class="container">
            <p>&copy; 2025 CarWash Management System. All Rights Reserved.</p>
            <p>
                <a href="#" class="text-white mx-2"><i class="bi bi-facebook"></i></a>
                <a href="#" class="text-white mx-2"><i class="bi bi-twitter"></i></a>
                <a href="#" class="text-white mx-2"><i class="bi bi-instagram"></i></a>
            </p>
        </div>
    </footer>