<?php include 'nav/header.php'; ?>
<section class="container my-5">
    <h2 class="text-center text-primary fw-bold mb-4">Contact Us</h2>
    <div class="row g-4">
        <div class="col-md-6">
            <div class="p-4 bg-primary text-white rounded shadow">
                <h5>Contact Info</h5>
                <p><i class="bi bi-geo-alt-fill"></i> Pawing, Palo, Leyte, Philippines</p>
                <p><i class="bi bi-telephone-fill"></i> +63 9317440217</p>
                <p><i class="bi bi-envelope-fill"></i> info@carwash.com</p>
            </div>
        </div>
        <div class="col-md-6">
            <form class="p-4 shadow rounded bg-light">
                <div class="mb-3">
                    <label class="form-label">Name</label>
                    <input type="text" class="form-control" placeholder="Your Name">
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" class="form-control" placeholder="Your Email">
                </div>
                <div class="mb-3">
                    <label class="form-label">Message</label>
                    <textarea class="form-control" rows="5" placeholder="Your Message"></textarea>
                </div>
                <button class="btn btn-primary w-100">Send Message</button>
            </form>
        </div>
    </div>
</section>
<?php include 'nav/footer.php'; ?>
