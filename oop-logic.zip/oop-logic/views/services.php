<?php include 'nav/header.php'; ?>
<section class="container my-5">
    <h2 class="text-center text-primary fw-bold mb-4">All Our Services</h2>
    <div class="row row-cols-1 row-cols-md-3 g-4">
        <?php 
        foreach($services as $s): ?>
        <div class="col">
            <div class="card text-white shadow-lg service-card h-100" 
                 style="background: url('<?= $s[1] ?>') no-repeat center center; background-size: cover;">
                <div class="card-body d-flex flex-column justify-content-center align-items-center p-4" 
                     style="background-color: rgba(0,0,0,0.5); border-radius: 15px;">
                    <h3 class="fw-bold"><?= $s[0] ?></h3>
                    <p class="text-center">Professional <?= $s[0] ?> for your vehicle.</p>
                    <button class="btn btn-light mt-auto">Book Now</button>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</section>
<?php include 'nav/footer.php'; ?>
