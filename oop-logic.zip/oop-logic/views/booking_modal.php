<!-- Booking Modal -->
<div class="modal fade" id="pricingModal" tabindex="-1" aria-labelledby="pricingModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <form method="post" action="../page/process_booking.php">
                <div class="modal-header">
                    <h5 class="modal-title" id="pricingModalLabel">Book a Car Wash</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="plan" class="form-label">Select Plan</label>
                        <select name="plan" id="plan" class="form-select" required>
                            <option value="Exterior Wash">Exterior Wash</option>
                            <option value="Interior Cleaning">Interior Cleaning</option>
                            <option value="Full Detailing">Full Detailing</option>
                            <option value="Engine Cleaning">Engine Cleaning</option>
                            <option value="Wax & Polishing">Wax & Polishing</option>
                            <option value="Tire & Wheel Care">Tire & Wheel Care</option>
                            <option value="Basic Wash">Basic Wash</option>
                            <option value="Premium Wash">Premium Wash</option>
                            <option value="Enterprise Package">Enterprise Package</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="name" class="form-label">Full Name</label>
                        <input type="text" name="name" id="name" class="form-control" placeholder="Your name" required>
                    </div>
                    <div class="mb-3">
                        <label for="contact" class="form-label">Contact Number</label>
                        <input type="tel" name="contact" id="contact" class="form-control" placeholder="09XX-XXX-XXXX" required>
                    </div>
                    <div class="mb-3">
                        <label for="carModel" class="form-label">Car Model</label>
                        <input type="text" name="carModel" id="carModel" class="form-control" placeholder="Toyota Vios, Honda Civic..." required>
                    </div>
                    <div class="mb-3">
                        <label for="date" class="form-label">Preferred Date</label>
                        <input type="date" name="date" id="date" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="book" class="btn btn-primary">Confirm Booking</button>
                </div>
            </form>
        </div>
    </div>
</div>