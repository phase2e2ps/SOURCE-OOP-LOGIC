<?php include 'nav/header.php'; ?>
<section class="container my-5 text-center">
    <h2 class="text-primary fw-bold mb-4">Why Choose Us</h2>
    <div class="row g-4">
        <div class="col-md-4">
            <i class="bi bi-person-badge-fill fs-1 text-primary"></i>
            <h5 class="mt-3">Professional Team</h5>
            <p>Experienced staff providing top-quality services.</p>
        </div>
        <div class="col-md-4">
            <i class="bi bi-lightning-charge-fill fs-1 text-primary"></i>
            <h5 class="mt-3">Quick Service</h5>
            <p>Fast and efficient car washes without compromising quality.</p>
        </div>
        <div class="col-md-4">
            <i class="bi bi-shield-check fs-1 text-primary"></i>
            <h5 class="mt-3">Trusted & Safe</h5>
            <p>Safe cleaning products and trusted methods for all vehicles.</p>
        </div>
    </div>
</section>
<?php include 'nav/footer.php'; ?>
