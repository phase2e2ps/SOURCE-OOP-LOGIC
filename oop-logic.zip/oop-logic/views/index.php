<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--Bootstrap CDN-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <!--Bootstrap Icons-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <title>CarWash Management System</title>
    <style>
        body {
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            color: #333;
        }

        header {
            background: #0d6efd;
            color: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        header .nav-link {
            color: #fff !important;
            font-weight: 500;
        }

        header .nav-link:hover {
            text-decoration: underline;
        }

        /* Carousel */
        #carouselExampleFade img {
            border-radius: 15px;
            object-fit: cover;
            height: 500px;
        }

        h2.section-title {
            font-weight: 700;
            color: #0d6efd;
            text-align: center;
            margin-bottom: 2rem;
        }

        /* Service Cards */
        .service-card {
            border-radius: 15px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .service-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
        }

        .service-card i {
            transition: transform 0.3s ease;
        }

        .service-card:hover i {
            transform: scale(1.3);
        }

        /* Pricing */
        .pricing-header h1 {
            font-weight: 700;
            color: #0d6efd;
        }

        .card {
            border-radius: 15px;
            transition: all 0.3s ease;
        }

        .card:hover {
            transform: translateY(-8px);
            box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.15);
        }

        .pricing-card-title {
            font-size: 2rem;
            font-weight: bold;
        }

        .btn-lg {
            border-radius: 10px;
            font-weight: 600;
        }

        /* Modal */
        .modal-content {
            border-radius: 15px;
            padding: 1rem;
        }

        /* Features */
        .feature-icon {
            font-size: 2rem;
            color: #0d6efd;
        }

        /* Testimonials */
        .testimonial-card {
            border-radius: 15px;
            padding: 2rem;
            background-color: #fff;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .testimonial-card:hover {
            transform: translateY(-5px);
        }

        /* Contact Section */
        .contact-section {
            background: #0d6efd;
            color: #fff;
            border-radius: 15px;
            padding: 2rem;
        }

        .contact-section input,
        .contact-section button {
            border-radius: 10px;
        }
    </style>
</head>

<body>
    <?php include "../nav/header.php" ?>
    <!-- Carousel -->
    <section class="container mb-5">
        <div id="carouselExampleFade" class="carousel slide carousel-fade">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="https://media.istockphoto.com/id/1287044692/photo/worker-washing-red-car-with-sponge-on-a-car-wash.jpg?s=612x612&w=0&k=20&c=_6WO9k1qkDub5CAEQgnORMduUoQJkU6w3jjVQTdTdwQ=" class="d-block w-100" alt="Exterior Wash">
                </div>
                <div class="carousel-item">
                    <img src="https://thumbs.dreamstime.com/b/man-worker-car-wash-washing-s-alloy-wheels-48893850.jpg" class="d-block w-100" alt="Wheel Cleaning">
                </div>
                <div class="carousel-item">
                    <img src="https://static.vecteezy.com/system/resources/previews/047/340/134/non_2x/modern-car-undergoing-automatic-wash-at-night-photo.jpg" class="d-block w-100" alt="Automatic Wash">
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
                <span class="carousel-control-next-icon"></span>
            </button>
        </div>
    </section>

    <!-- Services -->
    <section class="container my-5" id="services">
        <h2 class="section-title">Our Services</h2>
        <div class="row row-cols-1 row-cols-md-3 g-4">
            <div class="col">
                <div class="card shadow-lg text-center service-card h-100">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center p-4">
                        <i class="bi bi-droplet-fill fs-1 text-primary mb-3"></i>
                        <h3 class="fw-bold">Exterior Wash</h3>
                        <p>Complete body wash using premium foam shampoo and hand drying for a spotless finish.</p>
                        <button class="btn btn-primary mt-auto" data-bs-toggle="modal" data-bs-target="#pricingModal" data-service="Exterior Wash">Book Now</button>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card shadow-lg text-center service-card h-100">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center p-4">
                        <i class="bi bi-brush-fill fs-1 text-primary mb-3"></i>
                        <h3 class="fw-bold">Interior Cleaning</h3>
                        <p>Vacuuming, dashboard polish, seat and carpet cleaning, leaving your interior fresh and spotless.</p>
                        <button class="btn btn-primary mt-auto" data-bs-toggle="modal" data-bs-target="#pricingModal" data-service="Interior Cleaning">Book Now</button>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card shadow-lg text-center service-card h-100">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center p-4">
                        <i class="bi bi-stars fs-1 text-primary mb-3"></i>
                        <h3 class="fw-bold">Full Detailing</h3>
                        <p>Complete interior and exterior detailing, including engine cleaning and protective coatings.</p>
                        <button class="btn btn-primary mt-auto" data-bs-toggle="modal" data-bs-target="#pricingModal" data-service="Full Detailing">Book Now</button>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card shadow-lg text-center service-card h-100">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center p-4">
                        <i class="bi bi-gear-fill fs-1 text-primary mb-3"></i>
                        <h3 class="fw-bold">Engine Cleaning</h3>
                        <p>Thorough engine wash and degreasing to improve performance and longevity.</p>
                        <button class="btn btn-primary mt-auto" data-bs-toggle="modal" data-bs-target="#pricingModal" data-service="Engine Cleaning">Book Now</button>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card shadow-lg text-center service-card h-100">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center p-4">
                        <i class="bi bi-sparkle fs-1 text-primary mb-3"></i>
                        <h3 class="fw-bold">Wax & Polishing</h3>
                        <p>High-quality wax application to protect paint and enhance shine.</p>
                        <button class="btn btn-primary mt-auto" data-bs-toggle="modal" data-bs-target="#pricingModal" data-service="Wax & Polishing">Book Now</button>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card shadow-lg text-center service-card h-100">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center p-4">
                        <i class="bi bi-circle-fill fs-1 text-primary mb-3"></i>
                        <h3 class="fw-bold">Tire & Wheel Care</h3>
                        <p>Cleaning, polishing, and protection for wheels and tires to restore original luster.</p>
                        <button class="btn btn-primary mt-auto" data-bs-toggle="modal" data-bs-target="#pricingModal" data-service="Tire & Wheel Care">Book Now</button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Pricing Section -->
    <section class="container my-5" id="pricing">
        <div class="pricing-header text-center">
            <h1 class="display-4">Pricing Plans</h1>
            <p class="fs-5 text-muted">Choose the perfect wash plan for your car.</p>
        </div>
        <div class="row row-cols-1 row-cols-md-3 mb-3 text-center g-4">
            <div class="col">
                <div class="card shadow-sm">
                    <div class="card-header py-3">
                        <h4 class="my-0 fw-normal">Basic Wash</h4>
                    </div>
                    <div class="card-body">
                        <h1 class="card-title pricing-card-title">₱199</h1>
                        <ul class="list-unstyled mt-3 mb-4">
                            <li>Exterior wash</li>
                            <li>Rim cleaning</li>
                            <li>Quick dry</li>
                        </ul>
                        <button class="w-100 btn btn-lg btn-outline-primary" data-bs-toggle="modal" data-bs-target="#pricingModal" data-service="Basic Wash">Book Now</button>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card shadow-sm">
                    <div class="card-header py-3">
                        <h4 class="my-0 fw-normal">Premium Wash</h4>
                    </div>
                    <div class="card-body">
                        <h1 class="card-title pricing-card-title">₱499</h1>
                        <ul class="list-unstyled mt-3 mb-4">
                            <li>Basic wash +</li>
                            <li>Interior cleaning</li>
                            <li>Wax coating</li>
                        </ul>
                        <button class="w-100 btn btn-lg btn-primary" data-bs-toggle="modal" data-bs-target="#pricingModal" data-service="Premium Wash">Book Now</button>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card shadow-sm border-primary">
                    <div class="card-header py-3 text-bg-primary border-primary">
                        <h4 class="my-0 fw-normal">Enterprise Package</h4>
                    </div>
                    <div class="card-body">
                        <h1 class="card-title pricing-card-title">₱999</h1>
                        <ul class="list-unstyled mt-3 mb-4">
                            <li>Premium wash +</li>
                            <li>Full detailing</li>
                            <li>Engine cleaning</li>
                        </ul>
                        <button class="w-100 btn btn-lg btn-light text-primary" data-bs-toggle="modal" data-bs-target="#pricingModal" data-service="Enterprise Package">Book Now</button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features -->
    <section class="container my-5" id="features">
        <h2 class="section-title">Why Choose Us</h2>
        <div class="row g-4 text-center">
            <div class="col-md-4">
                <i class="bi bi-person-badge feature-icon mb-3"></i>
                <h5>Professional Team</h5>
                <p>Experienced staff providing top-quality services.</p>
            </div>
            <div class="col-md-4">
                <i class="bi bi-lightning-charge-fill feature-icon mb-3"></i>
                <h5>Quick Service</h5>
                <p>Fast and efficient car washes without compromising quality.</p>
            </div>
            <div class="col-md-4">
                <i class="bi bi-shield-lock-fill feature-icon mb-3"></i>
                <h5>Trusted & Safe</h5>
                <p>Safe cleaning products and trusted methods for all vehicles.</p>
            </div>
        </div>
    </section>

    <!-- Testimonials -->
    <section class="container my-5" id="testimonials">
        <h2 class="section-title">Customer Reviews</h2>
        <div class="row row-cols-1 row-cols-md-3 g-4">
            <div class="col">
                <div class="testimonial-card text-center">
                    <p>"Excellent service! My car looks brand new."</p>
                    <h6>- John Doe</h6>
                </div>
            </div>
            <div class="col">
                <div class="testimonial-card text-center">
                    <p>"Professional and fast. Highly recommended!"</p>
                    <h6>- Sarah Lee</h6>
                </div>
            </div>
            <div class="col">
                <div class="testimonial-card text-center">
                    <p>"Great detailing services. My car shines like never before!"</p>
                    <h6>- Mike Ross</h6>
                </div>
            </div>
        </div>
    </section>


    <!-- Booking Modal -->
    <?php include "./booking_modal.php" ?>


    <!-- Contact / Newsletter -->
    <section class="container my-5" id="contact">
        <h2 class="section-title text-center">Get in Touch</h2>
        <div class="row g-4">
            <div class="col-md-6">
                <div class="contact-section">
                    <h5>Contact Info</h5>
                    <p><i class="bi bi-geo-alt-fill"></i> Pawing, Palo, Leyte, Philippines</p>
                    <p><i class="bi bi-telephone-fill"></i> +63 9317440217</p>
                    <p><i class="bi bi-envelope-fill"></i> info@carwash.com</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="contact-section">
                    <h5>Subscribe to Newsletter</h5>
                    <form>
                        <div class="mb-3">
                            <input type="email" class="form-control" placeholder="Enter your email">
                        </div>
                        <button class="btn btn-light w-100 text-primary">Subscribe</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php include "../nav/footer.php" ?>
</body>

</html>