<?php include 'nav/header.php'; ?>
<section class="container my-5">
    <h2 class="text-center text-primary fw-bold mb-4">Pricing Plans</h2>
    <div class="row row-cols-1 row-cols-md-3 g-4">
        <?php 
        $plans = [
            ["Basic Wash","₱199",["Exterior wash","Rim cleaning","Quick dry"]],
            ["Premium Wash","₱499",["Basic + Interior cleaning","Wax coating"]],
            ["Enterprise Package","₱999",["Premium + Full detailing","Engine cleaning"]]
        ];
        foreach($plans as $p): ?>
        <div class="col">
            <div class="card shadow-sm h-100 text-center">
                <div class="card-header py-3 bg-primary text-white">
                    <h4 class="my-0 fw-normal"><?= $p[0] ?></h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title pricing-card-title"><?= $p[1] ?></h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <?php foreach($p[2] as $item): ?>
                        <li><?= $item ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <button class="btn btn-primary w-100">Book Now</button>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</section>
<?php include 'nav/footer.php'; ?>
