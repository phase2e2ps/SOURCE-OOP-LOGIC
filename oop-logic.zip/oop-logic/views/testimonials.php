<?php include 'nav/header.php'; ?>
<section class="container my-5">
    <h2 class="text-center text-primary fw-bold mb-4">Customer Reviews</h2>
    <div class="row g-4">
        <?php 
        $reviews = [
            ["Excellent service! My car looks brand new.","John Doe"],
            ["Professional and fast. Highly recommended!","Sarah Lee"],
            ["Great detailing services. My car shines like never before!","Mike Ross"]
        ];
        foreach($reviews as $r): ?>
        <div class="col-md-4">
            <div class="p-4 shadow rounded bg-light text-center">
                <p>"<?= $r[0] ?>"</p>
                <h6>- <?= $r[1] ?></h6>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</section>
<?php include 'nav/footer.php'; ?>
