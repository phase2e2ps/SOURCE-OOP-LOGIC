document.addEventListener("DOMContentLoaded", function () {
  const bookingForm = document.getElementById("bookingForm");
  if (!bookingForm) return;

  bookingForm.addEventListener("submit", function (e) {
    e.preventDefault();
    let booking = {
      name: document.getElementById("custName").value,
      phone: document.getElementById("custPhone").value,
      car: document.getElementById("custCar").value,
      plan: document.getElementById("custPlan").value,
      date: document.getElementById("custDate").value,
      status: "Pending"
    };
    let bookings = JSON.parse(localStorage.getItem("bookings")) || [];
    bookings.push(booking);
    localStorage.setItem("bookings", JSON.stringify(bookings));
    alert("✅ Booking confirmed!");
    bookingForm.reset();
    bootstrap.Modal.getInstance(document.getElementById("bookingModal")).hide();
  });
});
