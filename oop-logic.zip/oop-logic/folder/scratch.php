<!-- Header / Navbar -->
<header class="sticky-top bg-primary shadow-sm">
    <div class="container d-flex flex-wrap align-items-center justify-content-between py-3">

        <!-- Logo / Brand -->
        <a href="#" class="d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none fs-4 fw-bold">
            🚗 CarWash Management
        </a>

        <!-- Navbar toggle for mobile -->
        <button class="navbar-toggler d-lg-none btn btn-light" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Navbar links -->
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="nav nav-pills">
                <li class="nav-item"><a href="#" class="nav-link text-white px-3">Dashboard</a></li>
                <li class="nav-item"><a href="#services" class="nav-link text-white px-3">Services</a></li>
                <li class="nav-item"><a href="#pricing" class="nav-link text-white px-3">Pricing</a></li>
                <li class="nav-item"><a href="#features" class="nav-link text-white px-3">Why Us</a></li>
                <li class="nav-item"><a href="#testimonials" class="nav-link text-white px-3">Testimonials</a></li>
                <li class="nav-item"><a href="#contact" class="nav-link text-white px-3">Contact</a></li>
                <li class="nav-item"><a href="../admin/dashboard.php" class="nav-link text-white px-3 fw-bold border border-light rounded">Admin</a></li>
            </ul>
        </div>
    </div>
</header>

<!-- Optional CSS for hover effect -->
<style>
    header .nav-link {
        transition: all 0.3s ease;
    }
    header .nav-link:hover {
        background-color: rgba(255,255,255,0.2);
        border-radius: 8px;
        text-decoration: none;
    }
    .navbar-toggler {
        border: none;
    }
</style>
