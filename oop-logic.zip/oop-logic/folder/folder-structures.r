carwash-system/
│
├── admin/        (Admin dashboard files)
├── carousel/     (Carousel images or slider files)
├── css/          (All CSS files)
├── nav/          (Navbar/header/footer partials)
├── views/        (Booking pages, contact, about, etc.)
└── index.php     (Default landing page)



admin/
├── css/               (admin-specific CSS)
│   └── style.css
├── js/                (admin JS)
│   └── script.js
├── index.php          (admin login page)
├── dashboard.php      (admin main dashboard)
├── bookings.php       (view all bookings)
└── header.php         (admin navbar/header)


#----------------------------------------------------------------#
#---------------CarWash Management System frontend---------------#
#----------------------------------------------------------------#

carwash/
├── admin/          (Admin panel)
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   └── script.js
│   ├── index.php          (Admin login)
│   ├── dashboard.php
│   ├── bookings.php
│   └── header.php
├── carousel/       (Carousel images)
├── css/
│   └── style.css   (Frontend styles)
├── nav/            (Navigation include)
│   └── navbar.php
├── views/          (Optional: contact form, about page)
│   ├── contact.php
│   └── about.php
└── index.php       (Landing page / default)
